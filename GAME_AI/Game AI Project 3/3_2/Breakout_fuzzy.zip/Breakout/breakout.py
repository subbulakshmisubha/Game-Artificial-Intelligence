# -*- coding: utf-8 -*-

import sys
import time
import numpy as np
import skfuzzy as fuzz
import pygame
import random
import matplotlib.pyplot as plt

font = {'family': 'serif',
        'color':  'darkred',
        'weight': 'normal',
        'size': 16,
        }


def get_ball_speed():
    '''
    Method to Get Ball Speed countinously increasing with time
    '''
    return ((int(time.time() - start_time))/100)


class StartGame():

    def main(self, init_bat_speed=3, xspeed_init=3,
             yspeed_init=3, max_lives=3, score=0):
        '''
        Method to initialize all the values
        '''
        global start_time
        global number_of_matches_won
        number_of_matches_won = 0
        start_time = time.time()
        bgcolour = pygame.image.load("background.jpg")
        size = width, height = 620, 480
        pygame.init()
        pygame.display.set_caption('Breakout')
        screen = pygame.display.set_mode(size)
        bat = pygame.image.load("paddle.jpg").convert()
        batrect = bat.get_rect()
        ball = pygame.image.load("ball.png").convert()
        ball.set_colorkey((255, 255, 255))
        ballrect = ball.get_rect()
        print("Ball get rect output",ballrect)
        wall = Brick()
        wall.build_level(width)
        batrect = batrect.move((width / 2) - (batrect.right / 2), height-30)
        ballrect = ballrect.move(width / 2, height / 2)
        xspeed = xspeed_init
        yspeed = yspeed_init
        lives = max_lives
        clock = pygame.time.Clock()
        pygame.key.set_repeat(1, 30)
        pygame.mouse.set_visible(0)
        bat_speed = init_bat_speed
        #list split contains the list which has 3 other lists embedded in it with the probabilities of the screen which has been split into 3 parts.
        list_split = fuzzyfy(width,xspeed) 
        while 1:
            clock.tick(500)

            # Enabling Events to close the Game
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        sys.exit()

            # Checking if bat has hit the ball
            if ballrect.bottom >= batrect.top \
                and ballrect.bottom <= batrect.bottom \
                and ballrect.right >= batrect.left \
                    and ballrect.left <= batrect.right:
                    yspeed = -yspeed

            # Move Ball increaing Speed with Time
            if xspeed < 0:
                xspeed = xspeed - get_ball_speed()
            else:
                xspeed = xspeed + get_ball_speed()
            if yspeed < 0:
                yspeed = yspeed - get_ball_speed()
            else:
                yspeed = yspeed + get_ball_speed()
            ballrect = ballrect.move(xspeed, yspeed)
            if ballrect.left < 0 or ballrect.right > width:
                xspeed = -xspeed
            if ballrect.top < 0:
                yspeed = -yspeed

            # Move Bat with input speed from one end to other
            print("Current Bat Speed : %s and Bat Rect %s" % (bat_speed,batrect))  
 
            bat_speed_rect=fuzzify_rules(list_split[0],list_split[1],list_split[2],ballrect,batrect,width)  
            print ("bat_speed returned from function",bat_speed_rect)
            # Checking if bat hit the wall
            if batrect.left < 0 or batrect.right > width:
                bat_speed = -bat_speed
            batrect = bat_speed_rect.move(bat_speed, 0)
            print ("bat rect updationn",batrect)
            
            
            # check if ball has gone past bat - lose a life
            if ballrect.top > height:
                lives -= 1
                xspeed = xspeed_init
                yspeed = yspeed_init
                if random.random() > 0.5:
                    xspeed = -xspeed
                ballrect.center = width * random.random(), height / 3
                batrect = bat.get_rect()
                batrect = batrect.move((width / 2) - (batrect.right / 2), height-30)
                if lives == 0:
                    game_over = pygame.font.Font(None, 80)\
                        .render("Game Over", True, (0, 128, 128), bgcolour)
                    game_over_rect = game_over.get_rect()
                    game_over_rect = game_over_rect.move(
                            width / 2 - (game_over_rect.center[0]), height / 3)
                    screen.blit(game_over, game_over_rect)
                    pygame.display.flip()
                    return(score)

            # Checking if ball has hit any wall
            if xspeed < 0 and ballrect.left < 0:
                xspeed = -xspeed
            if xspeed > 0 and ballrect.right > width:
                xspeed = -xspeed

            # Checking if bat has hit any wall
            if batrect.left < 0 and bat_speed < 0:
                bat_speed = -bat_speed
            if bat_speed > 0 and batrect.right > width:
                bat_speed = -bat_speed

            # If bircks are hit Delete the Brick
            index = ballrect.collidelist(wall.brickrect)
            if index != -1:
                if ballrect.center[0] > wall.brickrect[index].right \
                        or ballrect.center[0] < wall.brickrect[index].left:
                    xspeed = -xspeed
                else:
                    yspeed = -yspeed
                wall.brickrect[index:index + 1] = []
                score += 10

            # Displaying Score on Screen
            screen.blit(bgcolour, (0, 0))
            scoretext = pygame.font.Font(None, 40)\
                .render("Score : " + str(score), True, (0, 128, 128), bgcolour)
            scoretextrect = scoretext.get_rect()
            scoretextrect = scoretextrect.move(scoretextrect.left + 5, 0)
            screen.blit(scoretext, scoretextrect)

            batspeedtext = pygame.font.Font(None, 40)\
                .render("Bat Speed : " + str(abs(bat_speed)),
                        True, (0, 128, 128), bgcolour)
            batspeedtextrect = batspeedtext.get_rect()
            batspeedtextrect = batspeedtextrect.move(
                    batspeedtextrect.right + (width/3 - 10), 0)
            screen.blit(batspeedtext, batspeedtextrect)

            for i in range(0, len(wall.brickrect)):
                screen.blit(wall.brick, wall.brickrect[i])

            # If there is no bricks left on Screen Declare Player winner
            if wall.brickrect == []:
                number_of_matches_won += 1
                winner = pygame.font.Font(None, 80)\
                    .render("You Won", True, (0, 128, 128), bgcolour)
                winnerrect = winner.get_rect()
                winnerrect = winnerrect.move(
                        width / 2 - (winnerrect.center[0]), height / 3)
                screen.blit(winner, winnerrect)
                pygame.display.flip()
                return(score)

            screen.blit(ball, ballrect)
            screen.blit(bat, batrect)
            pygame.display.flip()


class Brick():
    '''
    Class For defining Bricks
    '''
    def __init__(self):
        self.brick = pygame.image.load("brick.png").convert()
        brickrect = self.brick.get_rect()
        self.bricklength = brickrect.right - brickrect.left
        self.brickheight = brickrect.bottom - brickrect.top

    def build_level(self, width):
        xpos = 0
        ypos = 60
        gap = 5
        adj = 0
        self.brickrect = []
        for i in range(0, 44):
            if xpos > width:
                adj = 0
                xpos = -adj
                ypos += self.brickheight
            self.brickrect.append(self.brick.get_rect())
            self.brickrect[i] = self.brickrect[i].move(xpos, ypos)
            xpos = xpos + self.bricklength + gap




#function to generate the memebership functions
def fuzzyfy(screen_width,ball_position):
	
	list_split=[]
	x=np.arange(screen_width)
	left_most = screen_width/3
	middle_width = screen_width
	left = fuzz.trimf(x, [0,(screen_width/3)/2,screen_width/3])
	middle = fuzz.trimf(x, [screen_width/3,screen_width/2,(screen_width - screen_width/3)])
	right = fuzz.trimf(x, [(screen_width - screen_width/3),(0 + (2*screen_width/3) + (screen_width/3)/2 ),screen_width])
	list_split.append(left)
	list_split.append(middle)
	list_split.append(right)
	return list_split

#the function which has all the fuzzify rules in it for the paddle movement according to the probabilities of the ball.	
def fuzzify_rules(left,middle,right,ballrect,batrect,screen_width):

	print("ball rect in rules",ballrect)	
	ball_position= ballrect[0]
	print("ball position in rules",ball_position)
	print("bat rect in rules",batrect)
	paddle_position= batrect[0]
	print("Bat position in rules",paddle_position)	
	#condition to check if the ball has gone out of the screen width
	if ball_position >=screen_width:
		ball_position=screen_width-1
	#condition to check is the ball is gone out of the left end of the screen.
	if ball_position < 0:
		ball_position=0	

	#checking if the ball probability in the left membership function is higher than that in the middle .	  
	if left[ball_position] > middle[ball_position]:
		print("The ball is in left")
		print("value", (left[ball_position]*ball_position))
		value = (left[ball_position]*ball_position)
		batrect[0] = value
		print ("updated rectangle",batrect)
	#checking if the ball probability in the middle left membership function is higher than that in the left .	
	elif left[ball_position] < middle[ball_position]:
		print("The ball is in middle left")
		print("value", (middle[ball_position]*ball_position))
		value = (middle[ball_position]*ball_position)
		batrect[0] = float(value)
		print ("updated rectangle",batrect)
	#checking if the ball probability in the middle  membership function is higher than that in the left .		
	elif middle[ball_position] > left[ball_position]:
		print("The is in middle")
		print("value", (middle[ball_position]*ball_position))
		value = (middle[ball_position]*ball_position)
		batrect[0] = float(value)
		print ("updated rectangle",batrect)
	#checking if the ball probability in the left membership function is higher than that in the middle left .
	elif middle[ball_position] < left[ball_position]:
		print("The ball is in middle left")
		print("value", (left[ball_position]*ball_position))
		value = (left[ball_position]*ball_position)
		batrect[0] = float(value)
		print ("updated rectangle",batrect)
	#checking if the ball probability in the middle membership function is higher than that in the right .
	elif middle[ball_position] > right[ball_position]:
		print("The ball is in middle")
		print("value", (middle[ball_position]*ball_position))
		value = (middle[ball_position]*ball_position)
		batrect[0] = float(value)
		print ("updated rectangle",batrect)
	#checking if the ball probability in the right membership function is higher than that in the middle  .
	elif middle[ball_position] < right[ball_position]:
		print("The ball is in right")
		print("value", (right[ball_position]*ball_position))
		value = (right[ball_position]*ball_position)
		batrect[0] = float(value)
		print ("updated rectangle",batrect)
	#checking if the ball probability in the middle right membership function is higher than that in the middle left .
	elif right[ball_position] > middle[ball_position]:
		print("The ball is in middle right")
		print("value", (right[ball_position]*ball_position))
		value = (right[ball_position]*ball_position)
		batrect[0] = float(value)
		print ("updated rectangle",batrect)
	#checking if the ball probability in the middle membership function is higher than that in the middle right .
	elif right[ball_position] < middle[ball_position]:
		print("The ball is in middle right")
		print("value", (middle[ball_position]*ball_position))
		value = (middle[ball_position]*ball_position)
		batrect[0] = float(value)
		print ("updated rectangle",batrect)

	else:
		value = ball_position
		batrect[0] = float(value)
		print ("updated rectangle",batrect)

	return batrect
if __name__ == '__main__':
    number_of_games = 5
    final_score = []
    startgame = StartGame()
    for i in range(0, number_of_games):
        print("Playing Game For - %s " % str(i+1))
        final_score.append(startgame.main())

